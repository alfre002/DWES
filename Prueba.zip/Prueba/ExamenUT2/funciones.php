<?php

function precioIVA ($precio) {
    return $precio + ($precio * 0.21);
}

?>