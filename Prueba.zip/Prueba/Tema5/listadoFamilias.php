<?php

require_once './DB.php';

try {
    $stock = DB::obtenerFamilias();
} catch (Exception $ex) {
    $mensaje = 'Error: ' . $ex->getMessage();
}

?>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="dwes.css" rel="stylesheet" type="text/css">
    </head>
    <body>
        <div id="encabezado">
            <h1>Listado de Familias</h1>   
        </div>
        <br>
        <div id="contenido">
            <h2> Familias </h2>

            <ul>
                <?php foreach ($stock as $value): ?>
                    <li>
                        <a href="listadoProducto.php?familia=<?=$value['cod']?>"> <?= $value['nombre'] ?> </a>
                    </li>
                <?php endforeach ?>
            </ul>

        </div>
    </body>
</html>