<?php

class CestaCompra {
    // funcion que carga la cesta si existe o la crea si no existe
    public static function carga_cesta() {
        if(isset($_SESSION['cesta'])) {
            $cesta = $_SESSION['cesta'];
        } else {
            $_SESSION['cesta'] = [];
            $cesta = $_SESSION['cesta'];
        }
        return $cesta;
    }
    
    public function carga_articulo($cod, $unidades) {
        // si ya existe el producto en la cesta, suma las unidades
        if(array_key_exists($cod, $this->cesta)) {
            $unidades_numero = intval($this->cesta[$cod]['unidades']);
            $unidades_numero += $unidades;
            $this->cesta[$cod]['unidades'] = $unidades_numero;
        } else {
            try {
                $producto = DB::obtieneProducto($codProd);
                $this->cesta[$cod]['producto'] = $producto;
                $this->cesta[$cod]['unidades'] = $unidades;
            } catch (Exception $ex) {
                throw $ex;
            }
        }
    }
}

?>